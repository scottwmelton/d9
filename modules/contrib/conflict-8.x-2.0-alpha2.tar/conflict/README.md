[![Build Status](https://travis-ci.org/drupaldeploy/drupal-conflict.svg?branch=8.x-1.x)](https://travis-ci.org/drupaldeploy/drupal-conflict)

Conflict
========

Fieldwise conflict prevention and resolution.

## Content staging

This module is part of [the content staging suite for D8](https://www.drupal.org/project/deploy#d8).
