<?php

namespace Drupal\conflict\Entity;

abstract class EntityConflictUIResolverHandlerBase implements ConflictUIResolverHandlerInterface {}
