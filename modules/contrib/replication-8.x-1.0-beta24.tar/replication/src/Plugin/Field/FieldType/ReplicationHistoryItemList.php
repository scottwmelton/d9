<?php

namespace Drupal\replication\Plugin\Field\FieldType;

use Drupal\Core\Field\FieldItemList;

class ReplicationHistoryItemList extends FieldItemList {}
