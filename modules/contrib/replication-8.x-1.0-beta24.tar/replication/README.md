[![Build Status](https://travis-ci.org/relaxedws/drupal-replication.svg?branch=8.x-1.x)](https://travis-ci.org/relaxedws/drupal-replication) [![Code Climate](https://codeclimate.com/github/relaxedws/drupal-replication/badges/gpa.svg)](https://codeclimate.com/github/relaxedws/drupal-replication)



Replication
===========

Provides services and entities types to assist with and log content replication.
