[![Build Status](https://travis-ci.org/dickolsson/drupal-key_value.svg?branch=8.x-1.x)](https://travis-ci.org/dickolsson/drupal-key_value)

Key-Value Extensions
====================

Extends the core key-value API with a backend for lists and sorted sets that you can do range queries on.
