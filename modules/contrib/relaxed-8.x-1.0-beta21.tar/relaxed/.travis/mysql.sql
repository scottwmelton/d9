SET GLOBAL max_allowed_packet = 16777216;
