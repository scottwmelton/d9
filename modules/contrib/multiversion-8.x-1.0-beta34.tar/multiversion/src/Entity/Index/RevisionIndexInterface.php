<?php

namespace Drupal\multiversion\Entity\Index;

interface RevisionIndexInterface extends EntityIndexInterface { }
