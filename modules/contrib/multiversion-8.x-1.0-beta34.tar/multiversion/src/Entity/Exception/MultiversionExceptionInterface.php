<?php

namespace Drupal\multiversion\Entity\Exception;

interface MultiversionExceptionInterface {

  public function getEntity();

}
