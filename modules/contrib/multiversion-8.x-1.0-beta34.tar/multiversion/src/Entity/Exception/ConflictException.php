<?php

namespace Drupal\multiversion\Entity\Exception;

class ConflictException extends MultiversionException { }
