<?php

namespace Drupal\multiversion\Entity;

use Drupal\Core\Config\Entity\ConfigEntityInterface;

/**
 * Provides an interface for defining Workspace type entities.
 */
interface WorkspaceTypeInterface extends ConfigEntityInterface {

}
