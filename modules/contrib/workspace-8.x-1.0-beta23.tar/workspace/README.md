[![Build Status](https://travis-ci.org/relaxedws/drupal-workspace.svg?branch=8.x-1.x)](https://travis-ci.org/relaxedws/drupal-workspace)



Workspace
=========

Provides the ability to have multiple workspaces on a single site to facilitate things like full-site preview and content staging.
